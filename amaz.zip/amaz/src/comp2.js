import React, { Component } from 'react';
import Chips, { Chip } from './Chips'
 
const suggestions = [
  'Oliver Hansen',
  'Van Henry',
  'April Tucker',
  'Ralph Hubbard',
  'Omar Alexander',
  'Carlos Abbott',
  'Miriam Wagner',
  'Bradley Wilkerson',
  'Virginia Andrews',
  'Kelly Snyder',
];

class YourComponent extends Component {
 
  constructor(props) {
    super(props);
    this.state = {
      chips: []
    }
  }
 
  onChange = chips => {
    this.setState({ chips });
  }
 
  render() {
    return (
      <div>
        <Chips
          placeholder="Type a EMP name"
          value={this.state.chips}
          onChange={this.onChange}
          onClick={this.state.chips}
          suggestions={suggestions}
          fromSuggestionsOnly={true}
          highlightFirstSuggestion={true}
 
        />
      </div>
    );
  }
}

export default YourComponent;