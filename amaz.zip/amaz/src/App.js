import React from 'react';
import logo from './logo.svg';
import './App.css';
import MultipleSelect from './comp'
import  YourComponent from './comp2'
import ChipX from './ChipX'
function App() {
  return (
    <div className="App">
      <header className="App-header">

      AMAZON ASSIGNMENT FOR CHIP INPUT DEVELOPMENT

        <h4>First way</h4>

        <MultipleSelect></MultipleSelect>
        <h4>Second way</h4>
        <YourComponent></YourComponent>
        <br/>
      </header>
    </div>
  );
}

export default App;
